semaforo = "rojo"

if semaforo == "verde":
    print ("cruzar la calle")
else:
    print("esperar")

compra = 200

if compra <= 100:
    print("pago en efecrivo")
elif compra > 100 and compra < 300:
    print ("pago con tarjeta de debito")
else:
    print("pago con tarjeta de credito")

